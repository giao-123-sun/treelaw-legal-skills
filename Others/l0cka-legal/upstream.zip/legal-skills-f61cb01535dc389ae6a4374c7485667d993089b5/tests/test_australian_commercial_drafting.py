from __future__ import annotations

import re
import unittest
from pathlib import Path

from layout import PLUGIN, area_eval_files, area_markdown, area_skill_files
from test_plugin_structure import CONTRACT_HEADINGS, DRAFT, READY

ROOT = Path(__file__).resolve().parents[1]
AREA = "commercial-drafting"


class AustralianCommercialDraftingTests(unittest.TestCase):
    def test_each_skill_has_eval_coverage(self) -> None:
        skills = {path.parent.name for path in area_skill_files(AREA)}
        prompts = [path.read_text(encoding="utf-8") for path in area_eval_files(AREA, "prompt.md")]
        covered = {
            name
            for name in skills
            if any(re.search(rf"(?m)^name: {re.escape(name)} ", prompt) for prompt in prompts)
        }
        self.assertEqual(covered, skills)

    def test_result_contracts_match_document_family(self) -> None:
        for path in area_skill_files(AREA):
            vocabulary = DRAFT if path.parent.name.startswith("draft-") else READY
            with self.subTest(skill=path.parent.name):
                text = " ".join(path.read_text(encoding="utf-8").split())
                for required in (*CONTRACT_HEADINGS, *vocabulary):
                    self.assertIn(required, text)

    def test_all_local_document_links_resolve(self) -> None:
        for path in area_markdown(AREA):
            for target in re.findall(r"\[[^\]]*\]\(([^)\s]+)\)", path.read_text(encoding="utf-8")):
                if target.startswith(("http://", "https://", "#", "mailto:")):
                    continue
                with self.subTest(document=str(path.relative_to(ROOT)), target=target):
                    resolved = (path.parent / target.split("#", 1)[0]).resolve()
                    self.assertTrue(resolved.is_relative_to(PLUGIN))
                    self.assertTrue(resolved.is_file())

    def test_cross_plugin_handoffs_use_skill_names(self) -> None:
        expected = {
            "draft-privacy-policy": {
                "route-australian-privacy-jurisdiction",
                "assess-australian-privacy-issues",
                "check-australian-privacy-principles",
                "assess-automated-decision-transparency",
            },
            "draft-services-agreement": {
                "configure-employment-profile",
                "map-fair-work-obligations",
            },
            "review-draft-against-checklist": {
                "check-australian-privacy-principles",
                "assess-automated-decision-transparency",
                "map-fair-work-obligations",
            },
        }
        for skill, handoffs in expected.items():
            path = PLUGIN / "skills" / skill / "SKILL.md"
            text = path.read_text(encoding="utf-8")
            for handoff in handoffs:
                with self.subTest(skill=skill, handoff=handoff):
                    self.assertIn(f"`${handoff}`", text)


if __name__ == "__main__":
    unittest.main()
