# Changelog

This changelog records all notable repository changes.

The repository ships one plugin, `legal-skills`, with one version. The
repository does not have release tags. The current pull request remains under **Unreleased**, even when its
plugin manifests contain their intended release versions.

## Unreleased

### Changed

- **Breaking: one plugin.** The fifteen `australian-*` and `legal-*` plugins
  are merged into a single plugin, `legal-skills` 1.0.0. All 98 skills keep
  their names and behaviour and now install together, so cross-area
  hand-offs always resolve. The former plugins become practice areas listed
  in `catalog.json`, each with its own guide under `areas/` and its own
  law-checked date. To upgrade, uninstall the old plugins, then run
  `claude plugin install legal-skills@legal-skills --scope user` (or
  `codex plugin add legal-skills@legal-skills`). The old plugin names are no
  longer listed in either marketplace.
- Removed the cross-plugin `requires` and `handsOffTo` declarations, the
  generated "Other plugins" sections, the install-tracking steps in
  `route-legal-fact-pattern`, and `plugins/README.md`. A test now checks that
  every `$skill-name` a document names exists.
- `skills.json` is a flat skill-to-provenance map (registry version 3), and
  validation rejects `TODO` or `TBD` provenance placeholders.
- Evals moved to `plugins/legal-skills/evals/<area>-<case>/`.

- `australian-contract-review`: names the unverified NSW s 3A(2) lead and
  separates verified Queensland and Victorian contracting-out text from
  unconfirmed prohibition conclusions and commentary.

- `australian-contract-review`: corrects commencement-day subscription transition
  and variation precedence, distinguishes offer-stage disclosure scope, expands
  official Act/Part leads across all jurisdictions, clarifies reference-only
  drafting reuse, removes duplicated ACL paraphrases, and adds positive-path
  evals with distinct graders and task-shaped catalog prompts.

### Added

- `legal-cognitive-sparring` 0.1.0: twelve skills that spar with a qualified
  lawyer. Core sparring pressure-tests an argument, probes understanding,
  opposes as counsel, steelmans and then attacks, and role-plays a named
  decision-maker. Structure and gaps maps assumptions, lists blind spots,
  clarifies burden and standard, and red-teams evidence. Strategy challenges
  forum, timing, and settlement choices, checks a plain restatement for lost
  nuance, and runs a short oral drill. Jurisdiction, forum, and governing law
  are lawyer-supplied. The plugin states no legal rule, invents no citation,
  and leaves the outcome with the qualified lawyer. Includes a shared sparring
  contract and one synthetic eval per skill.

- `australian-consumer-competition` 0.1.0: seven practitioner-led skills for
  controlled profiles, consumer guarantees, marketing claims, merger notification,
  cartel and RPM risk, product safety and on-demand ACCC developments. Includes
  official-source controls, separate current/future reform status, merger pathways,
  urgent safety reporting candidates, specialist hand-offs and synthetic evals.

- `australian-contract-review` 0.1.0: seven skills for controlled review
  playbooks, inbound NDA triage, commercial agreement review, ACL/ASIC UCT
  screening, liability and indemnity analysis, negotiation memos and renewal
  registers. Reuses drafting, employment and privacy workflows, separates
  future subscription rules, records unverified state-law leads, and includes
  qualified-lawyer review controls and synthetic evals.

- `australian-employment-fair-work` 0.2.0: five new workflows for contract
  review, worker classification, discrimination and positive duties, restraints
  and underpayment exposure frameworks. Reuses the employment profile, commercial
  and privacy resources; adds official-source controls and synthetic evals.
  Separates proposed non-compete reforms and uncommenced Queensland amendments.
  Review fixes restore the August plugin-wide law-check date, disclose unverified
  NSW limbs, reuse proposal/commencement owners, identify the DDA amendment,
  broaden deadline hand-offs, add record-burden and sexual-harassment routing,
  and track Queensland positive-duty proclamation status.

- `australian-commercial-drafting` 0.1.0: six practitioner-led skills for
  controlled drafting profiles, NDAs, SaaS/subscription terms, privacy policies,
  B2B services agreements and draft reviews. Includes original clause examples,
  an ACL unfair-terms checklist, official-source controls, specialist privacy
  and employment hand-offs, visible unresolved issues and synthetic evals.

- `benchmarks/`: a with/without-plugin benchmark harness (`run.py` over
  `claude -p` with a scratch working directory, plugin isolation and a
  publisher-only network allowlist; `score.py`) with 140 answer-keyed cases
  (citations, quotes, legislation, deadlines — genuine and fabricated, keyed
  against the official publishers or the deadlines script on 26 August 2026)
  and 37 rubric-scored scenarios across every plugin. Headline metrics: the
  with/without delta and the false-verification rate.

- Plugin dependencies. `catalog.json` now declares the other plugins a plugin
  `requires` (for example `australian-legal-research` for official-source
  verification, `australian-litigation-deadlines` for Fair Work Commission
  time limits) or `handsOffTo`. `generate_registry.py` derives every
  cross-plugin skill reference, fails when a declaration is missing or
  unused, and stamps an "Other plugins" section into each affected skill and
  a "Plugin dependencies" section into each plugin README. Each section tells
  the agent to report a missing plugin and treat its step as not done rather
  than perform it from memory. `plugins/README.md` and the router's skill map
  list the dependencies.

### Changed

- `australian-consumer-competition`: corrects standalone-asset screening to
  acquirer group Australian revenue, records the 1 April 2026 asset/voting-power
  application date, and adds ACL s 4 and ss 33–34 to marketing claim review.
  Official text checked for these follow-up claims; lawCheckedOn is unchanged.

- `australian-consumer-competition` 0.1.1: adds consumer-definition and s 45
  verification pathways, explicit competition exceptions and immunity leads,
  compilation-bounded general safety proposal status, specific watch triggers
  and a merger-forms watch item. Clarifies profile reuse and jurisdiction,
  improves metadata, adds a happy-path eval, tightens merger/safety graders
  and tests resolved cross-plugin links.

- `australian-employment-fair-work`: label the non-compete watch entry as the
  26 August 2026 position, distinguish the positive duty's 13 December 2022
  commencement from later AHRC powers, and identify s 327B as the small-business
  Code provision separately from s 327C criminal proceedings. Law-check dates
  remain unchanged.

- `legal-workflow-router` 0.2.0: `route-legal-fact-pattern` checks which
  routed skills are installed in the session, adds each routed plugin's
  required plugins as prerequisites, and lists missing plugins under
  "Install first". A missing plugin is no longer silently skipped or
  substituted, and a plan with uninstalled steps is at most `READY WITH
  QUALIFICATIONS`. New rubric scenario `route-legal-fact-pattern-004`.
- Patch bumps for the generated dependency sections:
  `australian-ai-governance` 0.1.2, `australian-aml-ctf` 0.1.2,
  `australian-corporations-governance` 0.1.2,
  `australian-employment-fair-work` 0.1.1,
  `australian-litigation-deadlines` 0.3.1,
  `australian-privacy-cybersecurity` 0.3.3.
- `skills.json` is now `registry_version` 2: a hand-edited map of plugin →
  skill → provenance sentence. The derived `path`, `plugin`,
  `plugin_version` and `targets` fields are gone (read them from the plugin
  directories and manifests), and the generator no longer writes the file.
  Validation fails when a shipped skill has no provenance sentence or the
  file names a skill that does not exist.
- `validate_repository.py` reuses the generator's plugin loader and no longer
  re-checks the marketplace catalogs and Codex wrappers that
  `generate_registry.py --check` already guarantees.
- `tests/test_plugin_structure.py` pins the skill set and result vocabulary of
  every plugin in one table; the privacy tests are merged into one file.
- `CONTEXT.md` and `CONTEXT-MAP.md` are folded into `docs/architecture.md`,
  and the README's layout, validation and benchmark sections are condensed.

- The README is rewritten for users: a plain-language intro, one-step
  install by asking your assistant, terminal commands folded away, and a
  short "Before you rely on it" section. Repository layout, validation,
  eval and benchmark commands move to `CONTRIBUTING.md`.

- New brand: a section-sign logo (`docs/assets/legal-skills-logo.svg`) and a
  README banner with light and dark variants, replacing the stock network
  banner.

### Fixed

- Eleven skills tightened after a benchmark hill climb on Sonnet 5.5. The
  estate assemblers return the instruction table when the precedent is
  missing. The triage workflow returns the full record when a precondition
  fails and names no referral service from memory. The limitation map routes
  verification and arithmetic and never says whether a claim is in time. The
  cyber map cites register ids. The AI guidance check keeps its snapshot
  dates when the publisher is unreachable. The board record returns
  placeholders instead of declining. The designated services map names its
  statutory anchor. The breach method lists AFS licensee reportable
  situations. The reporting map leaves the tipping-off call on telling the
  client to the lawyer.
- Benchmarks: runs no longer load plugins the operator installed, skills can
  read their own references, the judge reads any `.docx` deliverable and
  retries a failed call, the scratch directory no longer counts as
  contamination, and two rubrics stale since the one-plugin merge are
  refreshed. The README records the first run.

- Evals: every case with regex graders now has pass and fail sample replies
  under `tests/eval_samples/`, and CI runs each regex grader against them
  offline. A fail sample must trip at least one grader, and every grader must
  be tripped by some fail sample. The samples exposed three grader defects,
  now fixed. A `NOT VERIFIED` reply passed both genuine-citation cases (new
  `not-verified-absent` graders), and a reply citing "rule 14.3" failed the
  NSW defence case (the pattern now accepts `r 14.3` or `rule 14.3`).

- `australian-commercial-drafting`: distinguish current ACL controls from enacted
  unfair trading, drip-pricing and subscription reforms commencing 1 July 2027,
  with cohort, regulations and existing-contract transition checks. Add current
  privacy tort, code, overseas-prescription and penalty-tier controls; verify
  Fair Work commencement dates and clarify UCT and moral-rights citations.
  Refresh the scoped official-source snapshot to 13 October 2026 and expand
  synthetic workflow rubrics for these distinctions.

- `australian-commercial-drafting`: use installed skill names for privacy and
  employment hand-offs, explicitly route NSW verification and health-records
  coverage, narrow the ACL exclusion checklist to ss 26–28, and correct
  result-contract spacing and structural-test documentation.

- Currency review of 24 September 2026 (`docs/audits/2026-09-24-currency-audit.md`).
  The official publishers were unreachable during the review, so each
  post-snapshot development is recorded as reported and to be confirmed
  against its primary source; watch-register items carry `reviewed_on`,
  `status_at_review` and `review_basis`, and no `lawCheckedOn` date moved.
  Patch bumps: `australian-ai-governance` 0.1.1 → 0.1.2,
  `australian-aml-ctf` 0.1.1 → 0.1.2,
  `australian-corporations-governance` 0.1.1 → 0.1.2,
  `australian-employment-fair-work` 0.1.0 → 0.1.1,
  `australian-estate-planning` 0.5.0 → 0.5.1,
  `australian-litigation-deadlines` 0.3.0 → 0.3.1,
  `australian-privacy-cybersecurity` 0.3.2 → 0.3.3.
  - Privacy and AI governance: Privacy Act tranche 2 exposure draft
    (including the proposed 72-hour breach notification), National Cabinet's
    data-centre standards decision and the PM&C AI infrastructure
    consultation, the Joint Select Committee on AI, the closed ASX fifth
    edition consultation, Bunnings and Bekier status, SOCI tranche 2
    consultation, Children's Online Privacy Code registration deadline, and
    APP 1.7–1.9 numbering aligned across plugins.
  - AML/CTF: AML/CTF Amendment Bill 2026 watch item and its proposed
    LPP-form change, draft LPP guidelines recorded as consulted, the
    financial-year compliance report cycle, and past deadlines restated in
    the past tense.
  - Corporations: superseded Corporations Act compilation flagged, closed
    ASX and CPS 510 consultations, and future-change notes for External
    Reporting Australia and director IDs.
  - Employment: non-compete exposure draft, Clerks Award working-from-home
    decision, tabled Closing Loopholes review, HPSS decisions, the s 772
    unlawful-termination row and flexible-work section cites.
  - Estate planning: NSW Guardianship Regulation 2026 flagged for
    verification before drafting enduring guardianship instruments;
    Queensland skill no longer implies remote execution is available.
  - Litigation deadlines: WA public holiday Bill caveat, WA defamation
    single-publication exception, and stale snapshot wording.
  - Primary-source check of the review on 24 September 2026: the NT has
    adopted the Stage 1 defamation reforms (the WA-only exception is
    corrected); the 11 September 2026 gender-undervaluation decision is
    SCHADS, not HPSS; the Corporations Act compilation is C2026C00382
    (No 148); External Reporting Australia commences 1 December 2026;
    National Cabinet agreed to develop, not endorsed, data-centre
    standards; the AML/CTF Amendment Bill 2026 passed the House on
    16 September 2026; no starter-kit release after v1.1; and the
    non-compete watch item id no longer presumes a 2027 start. Home Affairs,
    NSW legislation and parlinfo pages remained unreachable, so items
    resting on them stay marked as reported.

### Removed

- `docs/harvey/`: the Harvey Agent Builder guides and framework notes. The
  skills remain provider-neutral; the `harvey-labs` licence attribution in
  `australian-privacy-cybersecurity` is unchanged.

## 2026-08-26 - Evals, currency, coverage and three new plugins

### Released versions

- New: `australian-employment-fair-work` 0.1.0, `legal-workflow-router` 0.1.0.
- Bumped for new skills or coverage: `australian-estate-planning` 0.5.0,
  `australian-litigation-deadlines` 0.3.0, `legal-evidence-workflows` 0.2.0.
- Patch bumps for the currency-sweep corrections and trigger tightening:
  `australian-legal-research` 0.1.0 → 0.1.1, `australian-aml-ctf` 0.1.0 → 0.1.1, `australian-ai-governance` 0.1.0 → 0.1.1, `australian-corporations-governance` 0.1.0 → 0.1.1, `australian-privacy-cybersecurity` 0.3.1 → 0.3.2, `legal-triage` 0.1.1 → 0.1.2.
- Unchanged: none; every plugin ships a `lawCheckedOn` of 2026-08-26.

### Removed

- Removed `generate-precedent-profile` and the public sidecar-profile,
  exact-anchor and precedent-drift architecture from
  `australian-estate-planning` (0.4.0). Precedent approval and version control
  now belong to the private deployment's senior-lawyer-maintained Vaults.

### Fixed

- Closed the three currency-sweep leftovers: C2024A00128 Schedule 1 Part 15
  now cites items 87–88 as amending and item 89 as the application
  provision; the CIRMP Rules registry entry records the Enhanced CIRMP
  amending instrument (F2026L00701) and its 12- and 24-month grace periods;
  AS ISO/IEC 42001:2023 is dated to its 16 February 2024 publication.
- Currency sweep of every plugin against the official publishers on
  26 August 2026. Corrections: `check-commonwealth-legislation` example now
  cites the correct Privacy Act compilation (No. 97, C2023C00347);
  Family Law Act anonymisation cited as pt XIVB s 114Q (s 121 repealed
  6 May 2024); NSW legislation helper described as offline; unverifiable
  NSW "3 working days" wording softened; AGLC5 status and HCA collection
  coverage dated; NSW remote witnessing (Electronic Transactions Act 2000
  s 14G) added to estate-planning formalities; AML/CTF Rules 2025
  commencement (31 March 2026) and Transitional Rules 2026 deadlines
  recorded; AI-governance dates corrected (APRA letter, eSafety Phase 2
  codes, AI6 tiers, DTA policy, NSW AIAF, WA page update); ASX 5th edition
  and draft CPS 510 consultation dates and climate reporting (s 292A,
  AASB S2) added to corporations governance; Cyber Security Act rules
  retitled (Ransomware Payment Reporting; Cyber Incident Review Board), an
  APRA and a Tasmanian URL replaced after 404s, and the ACMA domestic
  violence standard's commencement (1 July 2025) separated from its phased
  requirements; triage template review dates moved past today.
- Restricted both Federal Register API helpers to the official HTTPS host before
  opening a URL, preventing non-HTTP and off-host requests.
- Made procedural-deadline computation fail closed when an excluded-range date
  is malformed or a required holiday table is unavailable.
- Renamed the NSW estate-planning instruction-record schema from the generic
  `instruction-record-schema.md` to `nsw-instruction-record-schema.md`, matching
  the Victorian naming convention and making the jurisdiction explicit.

### Added

- Deployment guides for `build-document-index`, `build-privilege-log` and
  `map-evidence-inconsistencies`, eval cases for the Queensland estate skill
  and the three evidence skills, and a `CONTEXT.md` glossary for
  `legal-evidence-workflows`.
- New plugin `australian-employment-fair-work` (0.1.0) with five skills:
  `configure-employment-profile`, `map-fair-work-obligations`,
  `assess-termination-exposure`, `review-workplace-policy` and
  `track-fair-work-developments`. Ships a source-and-control method, an
  employment profile schema, dated framework, termination and policy-hook
  references with per-row evidence states (Fair Work Act Compilation No.
  73 of 7 July 2026; AWR 2026 figures; high income threshold $190,100 from
  1 July 2026) and a 15-item watch register, all checked against the
  official publishers on 26 August 2026. Time limits route to the
  litigation-deadlines script; no skill concludes fairness, adverse action
  or compliance.
- `australian-litigation-deadlines` (0.3.0): computed coverage extended to
  the Supreme, District and Magistrates or Local Courts of Western
  Australia, South Australia, Tasmania, the ACT and the Northern Territory,
  with computation-rule tables (appearance, defence and appeal periods,
  Christmas exclusions and registry-closure windows) and public-holiday
  tables for 2026–2027, each entry verified against the official publisher
  on 26 August 2026 or held `pending-verification` so the script refuses to
  compute it.
- New plugin `legal-workflow-router` (0.1.0) with `route-legal-fact-pattern`:
  turns a described matter into a sequenced plan of Legal Skills plugins and
  skills with the human decision owner at each step. Its skill map is
  generated from every SKILL.md description by `generate_registry.py`, so
  it cannot drift from the shipped plugins.
- `assemble-qld-estate-documents` in `australian-estate-planning` (0.5.0): a
  third jurisdictional drafting skill for Queensland wills and enduring
  powers of attorney, with a Queensland instruction record schema, a dated
  execution formalities reference verified against the official Queensland
  legislation publisher, and a matching deployment guide. Advance health
  directives are flagged, never drafted.
- Three new `legal-evidence-workflows` (0.2.0) skills sharing the chronology
  conventions: `build-document-index` (numbered, source-linked bundle
  index), `build-privilege-log` (candidate-only privilege log with roles,
  purpose on the face, circulation and waiver flags) and
  `map-evidence-inconsistencies` (fact-by-source matrix with divergence and
  corroboration registers). None decides relevance, privilege, credibility
  or merits.
- Added a required `lawCheckedOn` date to every plugin `catalog.json`. The
  validator fails when the date is malformed, in the future or older than 183
  days, and the generated plugin tables show it as a "Law checked" column.
- Added `claude plugin eval` suites under `plugins/<name>/evals/` for the
  fail-closed skills in `australian-legal-research`,
  `australian-litigation-deadlines`, `australian-aml-ctf`, `legal-triage`
  and `australian-privacy-cybersecurity` (13 cases), with a structural test
  in `tests/test_evals.py`.
- Added `scripts/check_links.py` and a weekly `Link check` workflow that
  probes every URL cited under `plugins/`, failing on 404/410 or unresolvable
  hosts and warning on bot-blocked or timed-out publishers.
- New plugin `legal-evidence-workflows` (0.1.0) with
  `build-evidence-chronology`: inventories supplied legal matter documents,
  extracts source-linked event candidates through a native structured review
  table when available, and builds an event-level chronology while preserving
  exact date wording, conflicting accounts, allegations, inferences and gaps.
  The final chronology is a generated `.docx` with a review scope, source-linked
  chronology table, conflict register, evidence gaps and source register; plain
  text, PDF and spreadsheet output cannot substitute for the Word deliverable.
  The plugin does not decide credibility, evidentiary weight, admissibility,
  legal effect or merits. A separate Harvey Agent Builder guide maps the
  provider-neutral skill to File Upload, Review Table, Prompt, Word-document
  creation and Response steps without duplicating the canonical workflow.
- `generate-precedent-profile` in `australian-estate-planning` (0.3.0):
  inspects uploaded clean NSW or Victorian firm estate precedents read-only,
  proposes exact sidecar site maps and schema coverage, registers only existing
  verbatim clause variants, and stops for responsible-solicitor confirmation.
  Executed, client-completed, matter-specific or structurally unstable uploads
  fail closed and are never copied into a profile.
- `assemble-vic-estate-documents` in `australian-estate-planning` (0.2.0):
  extends the solicitor-controlled assembly workflow to Victorian
  wills, enduring powers of attorney and appointments of medical treatment
  decision maker. Adds a Victorian instruction-record schema and a dated
  formalities snapshot verified against legislation.vic.gov.au on 2026-08-20,
  including the Powers of Attorney Regulations 2025 prescribed form.
- New plugin `australian-estate-planning` (0.1.0) with one skill,
  `assemble-nsw-estate-documents`: extracts a provenance-cited instruction
  record from a completed client instruction sheet, halts at a solicitor
  confirmation gate, and fills the firm's own NSW will, enduring power of
  attorney and appointment of enduring guardian precedents through separately
  confirmed sidecar profiles of exact factual and clause sites, returning a
  change manifest, gap report and a dated execution-formalities reference verified against
  legislation.nsw.gov.au (2026-08-20). The plugin ships no scripts — a
  deliberate departure from the script-only pattern, recorded in
  `docs/adr/0001-platform-neutral-no-script-document-assembly.md`, so the
  pack stays deployable as plain markdown on text-based agent platforms;
  `tests/test_australian_estate_planning.py` enforces the sidecar-profile,
  source-preservation, drift, fail-closed and no-platform-name invariants.
- First architecture decision records under `docs/adr/`, and a root
  `CONTEXT-MAP.md` splitting the registry-machinery glossary from the new
  plugin-domain glossary in
  `plugins/australian-estate-planning/CONTEXT.md`.

### Changed

- Tightened skill trigger descriptions where routing overlapped: the seven
  State and Territory legislation checkers now carry the same
  "in force / which version applied on a date" triggers as the Commonwealth
  and NSW checkers and exclude other jurisdictions; the three judgment
  verifiers state that `route-case-citation` sends citations to them;
  `map-australian-cyber-incident-obligations` defers full incident triage to
  `assess-australian-data-breach`; and
  `assess-ai-privacy-cybersecurity-use-case` hands the obligations map and
  board oversight to `australian-ai-governance`.
- Simplified `australian-estate-planning` (0.4.0) to two jurisdictional
  workflows, one for NSW and one for Victoria. Each run concerns one client,
  uses centrally maintained approved precedents and playbooks, and drafts all
  supported content in one run from provenance-cited instructions. Missing
  facts, conflicts and unsupported decisions are visibly marked in partial
  drafts and reconciled to a drafting-issues register. ADR 0003 records the
  public/private boundary, and separate Harvey deployment guides map each
  jurisdiction to a Workflow agent with an embedded Vault and exact file-name
  placeholders. The drafting workflow relies on senior-lawyer maintenance of
  those approved materials rather than adding live legal-research steps.

- Replaced the machine-marker requirement in both estate-planning skills with
  sidecar precedent profiles for ordinary human-designed firm precedents. The
  source precedent remains unchanged; a solicitor confirms exact structural
  locations and text anchors before first use; every later fill operates on a
  working copy and stops on fingerprint, anchor, target or occurrence-count
  drift. ADR 0002 records the replacement and preserves ADR 0001 as
  superseded decision history.
- Broadened `australian-estate-planning` metadata and shared controls from
  NSW-only to NSW and Victoria while keeping jurisdiction-specific schemas,
  formalities references and fail-closed routing.
- Defined explicit clause-choice assembly for `australian-estate-planning`:
  each registered clause site has a closed register of firm-approved verbatim variants,
  a playbook may identify but not create a variant, the responsible solicitor
  confirms it before insertion, and every unresolved choice makes that document
  `NOT READY`.
- Added a Description column to the README plugin table and rewrote each
  plugin's `shortDescription` as one or two short plain-English sentences;
  the same text flows to `plugins/README.md` and the ChatGPT Work interface
  metadata.
- Slimmed the README plugin table to plugin and skill count; the "What it
  does" and "Boundaries" detail remains in each plugin's README and in
  `catalog.json`.
- Made the evidence-states block of the four `*-source-and-control-method.md`
  documents a generated region: canonical bullet text lives in
  `scripts/generate_registry.py`, per-plugin qualification lists are declared
  as `evidenceStates` in `catalog.json`, and the migration preserved the
  current wording of every document word for word. The shared convention —
  the two status vocabularies, the generated block, the invariant sentences
  now asserted by `tests/test_plugin_structure.py` — is recorded in
  `docs/source-and-control-method-core.md`.
- Consolidated the four per-plugin copies of the structural test suite
  (expected skills, workflow/result-contract/fail-closed headings, READY
  status vocabulary, shared-method references) into one parametrized
  `tests/test_plugin_structure.py`; the per-plugin test files now carry only
  their plugin-specific legal invariants. The pinned skill sets moved with
  it: they are the guard against accidental skill-directory deletion now
  that `skills.json` is generated from the directories.
- Merged the six topic-named test files covering `australian-legal-research`
  (a fossil of the pre-merge plugin boundaries) into one
  `tests/test_australian_legal_research.py` with unchanged test classes.
- Made each plugin's `.claude-plugin/plugin.json` and a new hand-owned
  `catalog.json` the canonical registry sources, generated every other
  distribution surface from them with the new
  `scripts/generate_registry.py` (both marketplace catalogs, the
  `.codex-plugin/plugin.json` wrappers, `plugins/README.md`, the root
  README badges, counts, plugin table and install blocks, and the derived
  fields of `skills.json`), and added a `--check` drift gate to CI. New
  skills are now scaffolded into `skills.json` with an empty `source` that
  fails validation until the provenance sentence is written. Catalogs and
  the README table are now ordered alphabetically, and `plugins/README.md`
  again lists all seven plugins.
- Gave `australian-litigation-deadlines` (0.2.0) its previously missing
  ChatGPT Work interface metadata (display name, descriptions and default
  prompts) via its new `catalog.json`.

- Extended `australian-litigation-deadlines` (0.2.0) computed coverage to
  Queensland: new `qld-courts` and `qcat` computation-rule tables and a
  `qld` holiday table, all verified against legislation.qld.gov.au and the
  official Queensland Government holiday pages (checked 2026-08-14).
  Verified and computing: UCPR 1999 (Qld) r 137(1) notice of intention to
  defend (the defence attaches to it under r 139(1)(b), with SEPA and
  42-day outside-Australia displacement warnings) and r 748(a) notice of
  appeal, reckoned under the Acts Interpretation Act 1954 (Qld) s 38 —
  the UCPR has no time-reckoning rule of its own; the note to r 7 confirms
  s 38 governs through the Statutory Instruments Act 1992 s 14(1) and
  sch 1 bridge — and the QCAT Act 2009 s 33(3) general review period with
  relevant-day branches, enabling-Act displacement (s 6(7)) and the s 61(3)
  extension bar recorded as warnings. The Queensland holiday table is
  Brisbane-area based: the Royal Queensland Show day is included because
  appeals are filed at Brisbane (r 746(1)), the 96 other district show
  holidays are a caveat, and the Christmas Eve part-day holiday (6pm to
  midnight) is not counted as a non-business day. Shipped-table tests
  cover the Brisbane show-day rollover, the Christmas Eve business-day
  decision and the QCAT enabling-Act warning.

- Extended the `australian-litigation-deadlines` computation script with
  table-driven excluded-range support so Federal Court time reckoning is
  now expressible: a computation provision may declare recurring month-day
  excluded ranges (FCR r 1.61(5), 24 December to 14 January not counted)
  and a short-period threshold (r 1.61(3), periods of 5 days or less count
  business days only, so calendar-day rules at or under the threshold fail
  closed). Both FCR period rules (`fcr-defence-after-service`,
  `fcr-notice-of-appeal`) flipped to verified and now compute. Where
  rolling a last day under r 1.61(4) would enter the excluded range, the
  interaction with r 1.61(5) is legally unsettled, so the script refuses
  and refers the call to the responsible lawyer rather than choosing a
  reading. Excluded ranges combine only with calendar-day and business-day
  periods; months and years fail closed. Eight new fixtures cover periods
  spanning, inside and clear of the December-January window, the
  business-day interaction, both refusal gates and the roll-into-window
  refusal.

- Completed the initial publisher-verification pass over the
  `australian-litigation-deadlines` computation-rule tables against
  legislation.gov.au, legislation.nsw.gov.au and legislation.vic.gov.au
  (checked 2026-08-14). Verified and activated for computation: Acts
  Interpretation Act 1901 (Cth) s 36, FCR 2011 r 1.61, Interpretation Act
  1987 (NSW) s 36, UCPR r 1.11, UCPR rr 14.3(1) and 51.16(1)(c), the ART
  Rules 2024 r 5 general review period (citation corrected from the ART
  Act), Migration Act ss 477/477A, NCAT r 25(4)(c) (trigger corrected to
  the later of notification and first giving of reasons), Interpretation of
  Legislation Act 1984 (Vic) s 44 and the Victorian defence rule.
  Corrections from verification: the Supreme Court (General Civil
  Procedure) Rules 2015 (Vic) were replaced by the 2025 Rules
  (S.R. No. 85/2025) and all Victorian citations now reference the 2025
  instrument; the Victorian appearance rule stays pending because r 8.04
  fixes only minimum periods and the operative time is stated in the writ;
  the Federal Court period rules stay pending because FCR r 1.61(5)
  excludes 24 December to 14 January from the reckoning, which the script
  cannot yet express; NSW Interpretation Act s 36 is disapplied to the
  UCPR by r 1.11(5), so UCPR rules now rely on r 1.11 alone with a
  registry-closure warning; and the VCAT general 28-day review period was
  removed entirely — verification found no such period exists in the VCAT
  Act or Rules, so the enabling enactment always fixes it. Tests updated:
  verified entries must carry checked/method/version metadata, a shipped
  verified rule must compute, and shipped pending rules must still refuse.

### Added

- Added `australian-litigation-deadlines` 0.1.0 with six skills:
  `configure-litigation-deadline-profile`, `map-limitation-periods`,
  `compute-procedural-deadlines`, `map-tribunal-review-deadlines`,
  `maintain-deadline-register` and `verify-deadline-basis`. The plugin
  serves Australian legal practitioners running civil litigation. Every
  date it produces is provisional until the responsible lawyer confirms
  it, and the model never performs date arithmetic: a bundled
  deterministic script computes candidate dates from evidence-gated JSON
  computation-rule tables and refuses — returning identify-only output
  naming the governing rule — whenever an entry is unverified, a holiday
  table does not cover the computed range or intersects an uncertain
  window, or a period cannot be expressed. Rule tables ship as
  pending-verification routing leads that `verify-deadline-basis`
  activates against official publishers; NSW and Victorian holiday tables
  ship verified against the official government publications, including
  an uncertain window for the undeclared 2027 Grand Final Friday holiday.
  Limitation mapping covers all nine jurisdictions with special-regime
  flags and a conservative earliest-candidate marker; computed procedural
  coverage is staged to the federal courts, NSW, Victoria, the ART, NCAT
  and VCAT; migration outputs always carry a non-extendable and
  jurisdictional warning with a specialist-review flag. Accrual,
  discoverability and extension prospects stay with the lawyer; criminal
  procedure and foreign limitation law are excluded. Act verification
  routes to `australian-legal-research`; court rules carry their own
  source method because that plugin excludes them by design. The engine
  ships with 46 hand-derived and property fixtures covering weekend and
  holiday rollover, business-day counting across holiday clusters,
  month-end and leap-year arithmetic and every fail-closed gate.

- Added `australian-aml-ctf` 0.1.0 with five skills:
  `configure-aml-ctf-practice-profile`, `map-designated-services`,
  `review-aml-ctf-program`, `map-reporting-obligations` and
  `track-aml-ctf-developments`. The plugin serves Australian legal practices
  regulated under the tranche 2 AML/CTF reforms that commenced on
  1 July 2026. It creates a controlled practice profile, maps described
  legal services to the table 6 designated services in subsection 6(5B) of
  the amended AML/CTF Act using AUSTRAC's sufficiently-linked principles and
  the exemption carve-outs, issue-spots AML/CTF programs and
  customer-due-diligence frameworks against the Act, the AML/CTF Rules 2025
  and AUSTRAC's legal profession program starter kit, maps SMR, TTR and
  compliance-report triggers with the tipping-off offence and the
  legal-professional-privilege carve-outs and LPP-form mechanics, and checks
  a primary-source watch register on demand. Legislation verification stays
  with `australian-legal-research` and CDD-data privacy depth with
  `australian-privacy-cybersecurity` via `$skill` routing. The plugin covers
  legal practices only — other tranche 2 sectors fail closed to human
  review — and never enrols, lodges or submits anything to AUSTRAC, never
  performs customer due diligence, never concludes a matter is suspicious
  and never concludes that privilege applies.

- Added `australian-ai-governance` 0.1.0 with six skills:
  `configure-ai-governance-profile`, `map-ai-regulatory-obligations`,
  `assess-board-ai-oversight`, `check-ai-guidance-alignment`,
  `triage-government-ai-use-case` and `track-ai-regulatory-developments`. The
  plugin creates a controlled AI-governance profile, maps which Australian
  instruments currently bind an AI use case while flagging pending
  instruments — including the proposed Australian Standards for AI — as watch
  items only, issue-spots board and director-duty AI exposure, checks
  governance documentation against the AI6 guidance with the superseded
  Voluntary AI Safety Standard as detail catalogue and AS ISO/IEC 42001 as
  crosswalk, routes government AI use cases to the Commonwealth DTA policy or
  the eight state and territory assurance frameworks, and checks a
  primary-source watch register on demand. AI-privacy depth stays with
  `australian-privacy-cybersecurity` and board-process depth with
  `australian-corporations-governance` via `$skill` routing. The plugin never
  asserts pending law as in force, never certifies compliance with any
  standard and treats trackers such as policai.org as discovery indexes only.

- Added `australian-legal-research` 0.1.0, merging the `australian-legislation`
  0.2.0, `australian-case-law` 0.1.0 and `australian-legal-citation` 0.1.0
  plugins into a single research plugin with all sixteen skills unchanged.
  The three source plugins covered one workflow — verify legislation, verify
  case citations and quoted passages, cite under AGLC4 — and every skill keeps
  its name, so `$skill` cross-references from other plugins are unaffected.
  Users of the three superseded plugins should uninstall them and install
  `australian-legal-research@legal-skills` instead.

- Added `australian-corporations-governance` 0.1.0 with five skills:
  `configure-corporations-governance`, `assess-director-duties-governance`,
  `prepare-board-decision-record`, `review-corporations-governance-framework`
  and `maintain-corporations-governance-calendar`. The plugin configures a
  controlled governance profile, issue-spots decision-process risks, drafts
  board records, reviews governance frameworks and creates source-linked
  calendars for companies governed by the *Corporations Act 2001* (Cth). It
  separates ASX, APRA, ACNC and CATSI overlays, treats consultation drafts as
  non-operative, and never approves, files, executes or invents corporate action.

- Added `australian-legal-citation` 0.1.0 with one skill,
  `format-aglc4-citations`, ported from the author's private gt-skills
  workbench with firm-specific branding removed. The skill drafts, converts,
  reviews and corrects citations and bibliographies under the Australian
  Guide to Legal Citation, 4th edition, covering footnotes, pinpoints,
  subsequent references, cases, legislation, secondary sources, treaties,
  international and foreign materials, quotation treatment and citation
  audits. It ships an operational distillation with a source map recording
  provenance, chapter routing and missing appendices; it never invents a
  missing citation field and keeps formatting separate from source
  verification.

- Added `australian-case-law` 0.1.0 with five skills: `route-case-citation`,
  `verify-hca-judgment`, `verify-nsw-judgment`, `verify-federal-judgment` and
  `verify-case-quote`. The plugin verifies Australian case citations and
  quoted passages against the official court publishers, routes each citation
  by its medium-neutral court identifier, distinguishes `UNVERIFIABLE` from
  `NOT FOUND`, and never bypasses publisher bot challenges. Includes a shared
  case-law verification method reference, an offline citation parser and a
  structural and parser test suite.

- Added a shared point-in-time method reference to `australian-legislation`
  0.2.0 and gave every State and Territory checker the same full workflow,
  result contract and fail-closed sections that the Commonwealth and NSW
  checkers already had.
- Added worked examples, including a `VERIFIED WITH QUALIFICATIONS` result, to
  the Commonwealth legislation, data breach and triage skills.
- Extended repository validation to check skill descriptions, frontmatter
  form, relative links, `agents/openai.yaml` interface files, per-skill
  registry versions, plugin READMEs, and description, tag and keyword parity
  between manifests and both marketplace catalogs.
- Added a validator unit-test suite and structural tests for every
  jurisdiction checker's headings and result-contract fields.
- Added a CI Python version matrix, a ruff lint job with a pinned repository
  ruff configuration, a README badge-count check and compilation of all
  plugin helper scripts.
- Added `SECURITY.md` with a private vulnerability reporting path.

- Added `australian-legislation` 0.1.0, combining the existing Commonwealth and
  New South Wales workflows with official-source legislation checks for the
  Australian Capital Territory, Northern Territory, Queensland, South
  Australia, Tasmania, Victoria and Western Australia.
- Expanded `australian-privacy-cybersecurity` 0.3.0 with jurisdiction routing,
  a legislation-only statutory privacy tort assessment, date-gated automated
  decision transparency analysis and a Commonwealth cyber incident obligations
  matrix.
- Added current-law privacy and cybersecurity registries covering State and
  Territory privacy, health, surveillance, workplace and data breach overlays,
  together with Commonwealth sectoral cyber regimes.
- Added regression coverage for the combined legislation plugin, privacy and
  cyber registries, APP provenance controls and future-law transitions.

### Changed

- Simplified the README language and added a paste-ready Agent request for
  plugin installation.
- Recorded plugin descriptions, versions and keywords in the ChatGPT Work
  marketplace catalog so both catalogs carry the same discovery metadata.
- Documented the required `agents/openai.yaml` interface file, aligned the
  three pre-submission command checklists, and expanded the README plugin
  layout diagram.
- Documented each bundled helper script as optional and read-only, including
  which official publisher it contacts and how the skill degrades without
  command execution (`legal-triage` 0.1.1, `australian-privacy-cybersecurity`
  0.3.1).
- Restored Australian English spelling in the README.
- Strengthened APP verification so schema-valid user-supplied text cannot be
  described as authoritative without verified source provenance.
- Split APP analysis into statutory text, application perimeter, codes and
  instruments, known future amendments and OAIC guidance currency.
- Updated AI-system and data breach workflows to route concurrent privacy,
  cyber, sectoral and contractual obligations without treating case law as in
  scope.

### Removed

- Removed `scripts/check_readme_counts.py` and its CI step: the README
  badges are a generated region, so `generate_registry.py --check` already
  fails the build when they drift, and the satellite script re-ran the full
  validation a second time per CI job.
- Removed two vestigial tests (the superseded-plugin-directory tombstone and
  a single-skill duplicate of the validator's registry checks) and made the
  shipped computation-rule table count assertion derive from the shipped
  files instead of a hard-coded 8, so adding a jurisdiction no longer breaks
  an unrelated test.
- Removed the unused per-skill `version` field from `skills.json` and its
  validator check; plugin versions remain the only versioned surface.
- Removed the `australian-legislation`, `australian-case-law` and
  `australian-legal-citation` plugins, superseded by `australian-legal-research`
  0.1.0 above.

### Fixed

- Made the legal triage test fixture independent of the caller's home directory
  so repository validation is deterministic in CI.

## 2026-08-14 - Initial repository

### Added

- Created the provider-neutral Legal Skills marketplace for Claude Cowork and
  ChatGPT Work, with paired plugin manifests, a portable skill registry and
  offline repository validation.
- Added Commonwealth legislation verification and legislative change tracing.
- Added New South Wales legislation verification.
- Added governed community legal centre triage workflows.
- Added the initial Australian privacy, APP, data breach and AI use-case
  assessment workflows.
