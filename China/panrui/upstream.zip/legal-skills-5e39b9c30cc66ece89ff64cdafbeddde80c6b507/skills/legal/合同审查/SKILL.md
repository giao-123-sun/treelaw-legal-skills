---
name: 合同审查
description: "基于张海燕四步审查法+何力/常金光三观分析法，对合同进行深度审查。支持企业核验、多语言自动检测、Mermaid业务流程图、二段式审核意见、合同概览、客户可读合同编号、业务摘要、22类合同专项审查、续约提醒和 Word 修订模式审核红线稿。飞书正式交付物必须包含问题卡片列表和业务流程图；用户选择修订模式时，以原合同为只读来源，先生成 redline-plan.json，再运行 scripts/redline/apply_redline_plan.py 生成带真实修订痕迹和批注的 Word 审核修订稿，并完成红线 QA。其他记录保存为本地 Markdown。"
---

## 法律工作总控规则（强制）

执行本 Skill 前，必须先遵循：
- skills/legal/法律工作总控/references/practice-profile.md
- skills/legal/法律工作总控/references/matter-workspace-protocol.md
- skills/legal/法律工作总控/references/document-reading-protocol.md
- skills/legal/法律工作总控/references/source-boundary-protocol.md
- skills/legal/法律工作总控/references/ocr-correction-protocol.md
- skills/legal/法律工作总控/references/pkulaw-mcp-legal-verification-protocol.md

本 Skill 只处理「合同审查」专业任务；案件隔离、事项路径、文件读取、OCR 复查、来源披露、缺口归档、法规/案例/Wiki 核验和复盘台账更新均按法律工作总控共享协议执行。

## 旧规则废止（强制）

- 旧文中直接写死的客户目录、阶段目录、旧式台账写入、旧本地读取协议均不作为执行规则。
- 事项路径、当前事项、系统记录、业务文件区和复盘台账统一以法律工作总控 `matter-workspace-protocol.md` 为准。
- 不得静默写入复盘台账；确需更新时，先确认属于复盘台账更新并向用户说明。

# 合同审查助手

## 轻量入口

本文件是瘦身后的触发入口，只保留任务边界、执行顺序和按需读取索引。完整流程、模板、清单、专项规则和长示例已迁移至 `references/完整流程.md`。

## 何时使用

- 用户明确提到「合同审查」或本 Skill frontmatter 描述中的任务。
- 用户请求生成、审查、分析、计算、管理或推进与「合同审查」对应的法律工作成果。
- 法律工作总控或上游 Skill 路由到本 Skill。

## 执行顺序

1. 先按法律工作总控确认当前事项、业务文件区、系统记录区和来源边界。
2. 判断用户任务是否可以用本轻量入口完成；如只是路由、状态判断或简短提示，不默认读取完整流程。
3. 需要生成正式文书、报告、清单、计算结果、可视化、专项审查或复杂分析时，按需读取 `references/完整流程.md` 的相关章节。
4. 读取外置细节时，只读取当前任务需要的章节；不要为一个小问题整篇加载完整流程。
5. 输出前同步披露已读取材料、已核验内容、未核验/存疑内容、法规案例检索状态和需要用户判断事项。

## 按需读取索引

- `references/完整流程.md`：瘦身前完整正文，含详细流程、模板索引、专项规则、交互规范和注意事项。
- `references/修订策略.md`：用户要求 Word 修订模式、红线稿、批注修订版时读取，用于决定问题进入正文修订、批注或仅意见书。
- `references/redline-plan-protocol.md`：生成或执行 `redline-plan.json` 时读取，规定字段、路径、动作分流和 QA 要求。
- `references/`：本 Skill 的专业规则、清单、方法论和外置参考材料。
- `scripts/redline/apply_redline_plan.py`：合同红线执行器，将 `redline-plan.json` 落成真实 DOCX 批注和 `w:ins` / `w:del` 修订痕迹。
- `scripts/redline/qa_redline.py`：红线稿结构 QA，检查 `w:trackRevisions`、`w:ins`、`w:del`、批注和关系文件。
- `templates/`：文书、报告、表格等输出模板；仅在需要生成对应成果时读取。
- `assets/`、`scripts/`、`checklists/`、`reference/`：如目录存在，仅在完整流程或当前任务明确需要时读取。

## 输出底线

- 不跳过用户提供的材料；读取失败必须说明。
- 不用模型记忆替代法律法规核验；引用法规、案例、Wiki 或网页搜索时必须标注来源和核验状态。
- 材料不足时提示缺口，不悄悄补全。
- 需要写入系统记录、复盘台账、飞书文档或飞书日历时，按总控和对应飞书 Skill 规则执行。
